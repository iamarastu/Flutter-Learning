package com.example.scrroll

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
