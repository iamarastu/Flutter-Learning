package com.example.decoration

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
